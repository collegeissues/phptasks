<?php

namespace App\DataFixtures;

use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;
use App\Entity\Productp33;

class AppFixtures extends Fixture
{
    public function load(ObjectManager $manager): void
    {
        for ($i = 1; $i <= 10; $i++) {
            $product = new Productp33();
            $product->setName('Продукт ' . $i);
            $product->setPrice(mt_rand(100, 1000));
            $manager->persist($product);
        }
        $manager->flush();
    }
}